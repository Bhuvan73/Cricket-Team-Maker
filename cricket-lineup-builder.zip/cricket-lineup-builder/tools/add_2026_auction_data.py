#!/usr/bin/env python3
"""One-off, idempotent merge of the IPL 2026 auction data into data/*.json.
Sources are listed in SRC below. Run from the project root:  python3 tools/add_2026_auction_data.py
then:  python3 tools/make_data_js.py"""
import json, re, pathlib, copy
root = pathlib.Path(__file__).resolve().parent.parent / 'data'
P = json.load(open(root/'players.json', encoding='utf-8')); T = json.load(open(root/'teams.json', encoding='utf-8')); A = json.load(open(root/'auctions.json', encoding='utf-8'))
players = {p['id']: p for p in P['players']}; teams = {t['id']: t for t in T['teams']}
NAT = dict(IND='India', AUS='Australia', ENG='England', NZ='New Zealand', SA='South Africa', WI='West Indies', SL='Sri Lanka', AFG='Afghanistan', BAN='Bangladesh', ZIM='Zimbabwe')
TODAY = '2026-11-15'
P['sources'].update({
 'auction-2026-squads': dict(name='The Federal: IPL 2026 squads, full list of all 10 teams after auction (16 Dec 2025)', url='https://thefederal.com/sports/cricket/ipl-2026-final-squads-all-10-teams-after-auction-221072', type='press'),
 'auction-2026-unsold': dict(name='Wisden: IPL 2026 auction, complete list of players unsold, incl. accelerated-round sales (16 Dec 2025)', url='https://www.wisden.com/series/ipl-2026/cricket-news/ipl-2026-auction-complete-list-of-players-unsold', type='press'),
 'auction-2026-uncapped': dict(name='myKhel: IPL 2026 auction, full list of uncapped players sold (19 Dec 2025)', url='https://www.mykhel.com/cricket/ipl-2026-auction-csk-spent-the-most-on-uncapped-players-srh-bought-the-most-402374.html', type='press'),
 'debut-open-mag': dict(name='Open Magazine: IPL 2026 Debutants (28 Mar 2026, pre-season)', url='https://openthemagazine.com/sports/ipl-2026-debutants-full-list-of-new-players-record-auction-picks-and-rising-stars', type='press'),
 'debut-fpj': dict(name='Free Press Journal: debutants for CSK & RR, 30 Mar 2026 match report', url='https://www.freepressjournal.in/sports/ipl-2026-from-kartik-sharma-to-brijesh-sharma-check-list-of-debutants-for-chennai-super-kings-rajasthan-royals', type='press'),
 'debut-sportskhabri': dict(name='SportsKhabri: IPL 2026 top 5 emerging Indian pace bowlers (debut dates)', url='https://sportskhabri.com/ipl-2026-top-5-emerging-indian-pace-bowlers/', type='press'),
 'roles-editorial': dict(name='Project maintainer (roles assigned from general cricket knowledge; not an official source)', url=None, type='editorial')})
SA_, SU_, SUN_ = 'auction-2026-squads', 'auction-2026-uncapped', 'auction-2026-unsold'
def pid(n): return re.sub(r'[^a-z0-9]+', '-', n.lower()).strip('-')
def norm(n): return re.sub(r'[^a-z]', '', n.lower())

# name, team, price(cr), nat, role, uncapped, accelerated?, alias
SOLD = [
("Prashant Veer","csk",14.2,"IND","AR",True,0,None),("Kartik Sharma","csk",14.2,"IND","WK",True,0,None),("Rahul Chahar","csk",5.2,"IND","BOWL",None,1,None),
("Akeal Hosein","csk",2,"WI","BOWL",None,0,None),("Matt Henry","csk",2,"NZ","BOWL",None,1,None),("Matthew Short","csk",1.5,"AUS",None,None,0,None),
("Sarfaraz Khan","csk",.75,"IND","BAT",None,1,None),("Zakary Foulkes","csk",.75,"NZ","BOWL",None,0,"Zak Foulkes"),("Aman Khan","csk",.4,"IND",None,True,1,None),
("Auqib Nabi Dar","dc",8.4,"IND","BOWL",True,0,"Auqib Nabi"),("Pathum Nissanka","dc",4,"SL","BAT",None,1,None),("David Miller","dc",2,"SA","BAT",None,0,None),
("Ben Duckett","dc",2,"ENG","BAT",None,0,None),("Lungi Ngidi","dc",2,"SA","BOWL",None,1,None),("Kyle Jamieson","dc",2,"NZ","BOWL",None,1,None),
("Prithvi Shaw","dc",.75,"IND","BAT",None,1,None),("Sahil Parakh","dc",.3,"IND",None,True,0,"Sahil Parikh"),
("Jason Holder","gt",7,"WI","AR",None,1,None),("Tom Banton","gt",2,"ENG","BAT",None,1,None),("Ashok Sharma","gt",.9,"IND","BOWL",True,0,None),
("Luke Wood","gt",.75,"ENG","BOWL",None,0,None),("Prithviraj Yarra","gt",.3,"IND",None,True,0,"Prithvi Raj"),
("Cameron Green","kkr",25.2,"AUS","AR",None,0,None),("Mustafizur Rahman","kkr",9.2,"BAN","BOWL",None,1,None),("Matheesha Pathirana","kkr",18,"SL","BOWL",None,0,None),
("Tejasvi Singh","kkr",3,"IND","WK",True,0,"Tejasvi Dahiya"),("Finn Allen","kkr",2,"NZ","BAT",None,0,None),("Rachin Ravindra","kkr",2,"NZ","AR",None,1,None),
("Tim Seifert","kkr",1.5,"NZ","WK",None,0,None),("Akash Deep","kkr",1,"IND","BOWL",None,1,None),("Rahul Tripathi","kkr",.75,"IND","BAT",None,0,None),
("Prashant Solanki","kkr",.3,"IND",None,True,0,None),("Kartik Tyagi","kkr",.3,"IND","BOWL",True,0,None),("Sarthak Ranjan","kkr",.3,"IND",None,True,0,None),("Daksh Kamra","kkr",.3,"IND",None,True,0,None),
("Josh Inglis","lsg",8.6,"AUS","WK",None,1,None),("Mukul Choudhary","lsg",2.6,"IND","WK",True,0,None),("Akshat Raghuwanshi","lsg",2.2,"IND",None,True,0,None),
("Wanindu Hasaranga","lsg",2,"SL","AR",None,0,None),("Anrich Nortje","lsg",2,"SA","BOWL",None,0,None),("Naman Tiwari","lsg",1,"IND",None,True,0,None),
("Quinton de Kock","mi",1,"SA","WK",None,0,None),("Atharva Ankolekar","mi",.3,"IND",None,True,0,None),("Mohammad Izhar","mi",.3,"IND",None,True,0,None),
("Danish Malewar","mi",.3,"IND",None,True,0,None),("Mayank Rawat","mi",.3,"IND",None,True,1,None),
("Ben Dwarshuis","pbks",4.4,"AUS","BOWL",None,1,None),("Cooper Connolly","pbks",3,"AUS","AR",None,0,None),("Vishal Nishad","pbks",.3,"IND",None,True,1,None),("Pravin Dubey","pbks",.3,"IND",None,True,0,None),
("Ravi Bishnoi","rr",7.2,"IND","BOWL",None,0,None),("Adam Milne","rr",2.4,"NZ","BOWL",None,1,None),("Ravi Singh","rr",.95,"IND",None,True,0,None),
("Sushant Mishra","rr",.9,"IND","BOWL",True,0,None),("Kuldeep Sen","rr",.75,"IND","BOWL",None,1,None),("Vignesh Puthur","rr",.3,"IND","BOWL",True,0,None),
("Yash Raj Punja","rr",.3,"IND",None,True,0,"Yash Punja"),("Aman Rao Perala","rr",.3,"IND",None,True,0,"Aman Rao"),("Brijesh Sharma","rr",.3,"IND","BOWL",True,0,None),
("Venkatesh Iyer","rcb",7,"IND","AR",None,0,None),("Mangesh Yadav","rcb",5.2,"IND","BOWL",True,0,None),("Jacob Duffy","rcb",2,"NZ","BOWL",None,0,None),
("Jordan Cox","rcb",.75,"ENG","WK",None,1,None),("Satvik Deswal","rcb",.3,"IND",None,True,0,None),("Vicky Ostwal","rcb",.3,"IND","BOWL",True,1,None),
("Vihaan Malhotra","rcb",.3,"IND",None,True,0,None),("Kanishk Chouhan","rcb",.3,"IND",None,True,0,None),
("Liam Livingstone","srh",13,"ENG","AR",None,1,None),("Jack Edwards","srh",3,"AUS","BOWL",True,0,None),("Salil Arora","srh",1.5,"IND",None,True,0,None),
("Shivam Mavi","srh",.75,"IND","BOWL",None,1,None),("Shivang Kumar","srh",.3,"IND",None,True,0,None),("Krains Fuletra","srh",.3,"IND",None,True,0,None),
("Praful Hinge","srh",.3,"IND","BOWL",True,0,None),("Amit Kumar","srh",.3,"IND",None,True,0,None),("Onkar Tarmale","srh",.3,"IND",None,True,0,None),("Sakib Hussain","srh",.3,"IND","BOWL",True,0,None)]
assert len(SOLD) == 77, len(SOLD)
# Unsold: name, C(apped)/U(ncapped), nat
UNSOLD = ("Jake Fraser-McGurk|C|AUS;Devon Conway|C|NZ;Gus Atkinson|C|ENG;Jamie Smith|C|ENG;Deepak Hooda|C|IND;Wiaan Mulder|C|SA;Rahmanullah Gurbaz|C|AFG;Jonny Bairstow|C|ENG;K.S. Bharat|C|IND;Gerald Coetzee|C|SA;Spencer Johnson|C|AUS;Fazalhaq Farooqi|C|AFG;Maheesh Theekshana|C|SL;Mujeeb Ur Rahman|C|AFG;Sediqullah Atal|C|AFG;Sean Abbott|C|AUS;Michael Bracewell|C|NZ;Daryl Mitchell|C|NZ;Dasun Shanaka|C|SL;Chetan Sakariya|C|IND;Waqar Salamkheil|C|AFG;Daniel Lawrence|C|ENG;Taskin Ahmed|C|BAN;Richard Gleeson|C|ENG;Alzarri Joseph|C|WI;Riley Meredith|C|AUS;Jhye Richardson|C|AUS;Nathan Smith|C|NZ;William Sutherland|C|AUS;"
 "Aarya Desai;Yash Dhull;Abhinav Manohar;Anmolpreet Singh;Atharva Taide;Abhinav Tejrana;Mahipal Lomror;Rajvardhan Hangargekar;Vijay Shankar;Eden Apple Tom;Tanush Kotian;Kamlesh Nagarkoti;Ruchit Ahir;Sanvir Singh;Vansh Bedi;Tushar Raheja;Raj Limbani;Simarjeet Singh;Akash Madhwal;Wahidullah Zadran|U|AFG;Shivam Shukla;Karn Sharma;Kartikeya Singh;Salman Nizar;KM Asif;Murugan Ashwin;Tejas Baroka;KC Cariappa;Mohit Rathee;M. Dheeraj Kumar;Tanay Thyagarajann;Connor Esterhuizen|U|SA;Irfan Umair;Chintal Gandhi;Daniel Lategan|U|SA;Karan Lal;Utkarsh Singh;Ayush Vartak;Jikku Bright;Izaz Sawariya;Mani Sankar Mura Singh;Manan Vohra;Mayank Dagar;Money Grewal;Macneil Noronha;Siddharth Yadav;Ritik Tada;Chama Milind;Swastik Chikara;R.S. Ambrish").split(';')
unsold = []
for x in UNSOLD:
    f = x.split('|'); unsold.append((f[0], (f[1] if len(f) > 1 else 'U'), NAT[f[2]] if len(f) > 2 else 'India'))
assert len(unsold) == 79, len(unsold)
ALIAS_UNSOLD = {"Daniel Lawrence": "Dan Lawrence", "K.S. Bharat": "KS Bharat", "Mujeeb Ur Rahman": "Mujeeb Zadran"}
new_ids, upd_ids = set(), set()
def find_existing(name):
    i = pid(name)
    if i in players: return players[i]
    n = norm(name)
    for p in players.values():
        if norm(p['name']) == n or any(norm(a) == n for a in p.get('aliases', [])): return p
    return None
def mk(name, nat, role, src, ver='reported'):
    p = dict(id=pid(name), name=name, nationality=nat, role=role, roleSource='editorial' if role else None, teamHistory=[], uncapped=None, auctions=[], iplSquadSeasons=[],
             iplMatchSeasons=None, source=src, sources=[src], verification=ver, lastVerified=TODAY, notes=None)
    players[p['id']] = p; new_ids.add(p['id']); return p
def touch(p): 
    if p['id'] not in new_ids: upd_ids.add(p['id'])
    p['lastVerified'] = TODAY
def add_src(p, *k):
    p.setdefault('sources', [p.get('source')] if p.get('source') else [])
    for s in k:
        if s not in p['sources']: p['sources'].append(s)
def add_auction(p, rec):
    p['auctions'] = [a for a in p['auctions'] if a.get('season') != rec['season']] + [rec]

for name, team, price, nat, role, unc, acc, alias in SOLD:
    p = find_existing(name)
    if p is None: p = mk(name, NAT[nat], role, SA_)
    else: touch(p); 
    if role and not p.get('role'): p['role'] = role; p['roleSource'] = 'editorial'
    if alias: p['aliases'] = sorted(set(p.get('aliases', []) + [alias]))
    add_auction(p, dict(year=2025, season=2026, outcome='sold', team=team, priceCr=price, round='accelerated' if acc else 'main', source=SA_))
    add_src(p, SA_)
    if unc: p['uncapped'] = True; add_src(p, SU_)
    p['iplSquadSeasons'] = sorted(set(p.get('iplSquadSeasons', []) + [2026]))
    teams[team]['squad'] = teams[team].get('squad', [])
    # remove from any other squad / recent, put in the buying team (unless traded on afterwards, handled below)
    for t in teams.values():
        if p['id'] in t.get('squad', []) and t['id'] != team: t['squad'].remove(p['id'])
        if t['id'] == team and p['id'] in t.get('recentlyActive', []): t['recentlyActive'].remove(p['id'])
    if p['id'] not in teams[team]['squad']: teams[team]['squad'].append(p['id'])
    p['verification'] = p['verification'] if p['verification'] != 'official' else 'official'
players['jack-edwards']['notes'] = 'Bought by SRH at the IPL 2026 auction (Rs 3 cr, uncapped overseas); traded to CSK on 5 Nov 2026.'
# players bought at auction who were later traded: put them where they are now
for pidx, (to, note) in {'liam-livingstone': ('csk', 'Bought by SRH for Rs 13 cr in the accelerated round (unsold in round 1); traded to CSK on 5 Nov 2026 at Rs 6 cr.'), 'jack-edwards': ('csk', None)}.items():
    for t in teams.values():
        if pidx in t['squad']: t['squad'].remove(pidx)
    teams[to]['squad'].append(pidx)
    if note: players[pidx]['notes'] = note
players['liam-livingstone']['teamHistory'] = [h for h in players['liam-livingstone']['teamHistory'] if h['team'] == 'srh'] + [dict(team='rcb', period='IPL 2025 squad', type='released', note='Released by RCB before the IPL 2026 auction (press reports)')]
# Unsold
for name, cap, nat in unsold:
    p = find_existing(name)
    if p is None: p = mk(name, nat, None, SUN_); p['unverifiedFields'] = ['nationality']
    else: touch(p)
    if name in ALIAS_UNSOLD: p['aliases'] = sorted(set(p.get('aliases', []) + [ALIAS_UNSOLD[name]]))
    p['uncapped'] = (cap == 'U') if p.get('uncapped') is not True else True
    if not any(a.get('season') == 2026 and a['outcome'] == 'sold' for a in p['auctions']):
        add_auction(p, dict(year=2025, season=2026, outcome='unsold', team=None, priceCr=None, source=SUN_))
    add_src(p, SUN_)
# 2026 trade-ins named in the post-auction squads article (prior team in brackets there)
for name, prev, to in [("Sanju Samson","rr","csk"),("Nitish Rana","rr","dc"),("Arjun Tendulkar","mi","lsg"),("Mohammed Shami","srh","lsg"),("Shardul Thakur","lsg","mi"),
                       ("Sherfane Rutherford","gt","mi"),("Mayank Markande","kkr","mi"),("Donovan Ferreira","dc","rr"),("Ravindra Jadeja","csk","rr"),("Sam Curran","csk","rr")]:
    p = players[pid(name)]; touch(p); add_src(p, SA_)
    if not any(h['team'] == prev and h['type'] == 'traded-out' for h in p['teamHistory']):
        p['teamHistory'].append(dict(team=prev, period='IPL 2025 squad', type='traded-out', note='Traded to %s before IPL 2026 (per post-auction squad list)' % teams[to]['short']))
# KKR: Mustafizur released (BCCI directive, Jan 2026); Muzarabani signed as replacement
m = players['mustafizur-rahman']; touch(m); add_src(m, 'debut-open-mag')
if 'mustafizur-rahman' in teams['kkr']['squad']: teams['kkr']['squad'].remove('mustafizur-rahman')
if 'mustafizur-rahman' not in teams['kkr']['recentlyActive']: teams['kkr']['recentlyActive'].append('mustafizur-rahman')
m['teamHistory'] = [dict(team='kkr', period='IPL 2026 squad', type='released', note='Bought at the 2026 auction for Rs 9.2 cr; released in Jan 2026 after the BCCI asked KKR to release him')]
m['notes'] = 'Released by KKR in Jan 2026 (BCCI direction); replaced by Blessing Muzarabani.'
z = players.get('blessing-muzarabani') or mk('Blessing Muzarabani', 'Zimbabwe', 'BOWL', 'debut-open-mag'); z['iplSquadSeasons'] = [2026]
z['notes'] = 'Signed by KKR as the replacement for Mustafizur Rahman (Jan 2026). Not part of the auction.'; z['auctions'] = []
if z['id'] not in teams['kkr']['squad']: teams['kkr']['squad'].append(z['id'])
# Pathirana: now a bought KKR squad member (injured mid-season; replaced by Sisodia)
pa = players['matheesha-pathirana']; pa['teamHistory'] = []; pa['notes'] = 'Bought by KKR for Rs 18 cr; ruled out mid-season through injury (replacement: Luvnith Sisodia).'
# Miller was shown as 'recently active LSG' earlier; now DC via auction. Keep his LSG history (recent for LSG).
players['david-miller']['notes'] = 'Bought by DC for Rs 2 cr at the IPL 2026 auction; was in the 2025 LSG squad.'
# Fraser-McGurk: unsold at the 2026 auction
players['jake-fraser-mcgurk']['notes'] = 'Went unsold at the IPL 2026 auction (previously DC).'
for t in teams.values():
    if 'jake-fraser-mcgurk' in t.get('recentlyActive', []): pass
# ---------------- debut evidence ----------------
CONF = {'prashant-veer': ('2026-03-30', 'debut-fpj'), 'sakib-hussain': ('2026-04-13', 'debut-sportskhabri'), 'praful-hinge': ('2026-04-13', 'debut-sportskhabri'), 'ashok-sharma': ('2026-03-31', 'debut-sportskhabri')}
EXPECT = ['kartik-sharma','auqib-nabi-dar','ben-duckett','pathum-nissanka','finn-allen','blessing-muzarabani','jordan-cox','ben-dwarshuis','jacob-duffy','zakary-foulkes','brijesh-sharma']
for p in players.values(): p.pop('debutStatus', None); p.pop('debutSeason', None)
for i, (d, s) in CONF.items(): p = players[i]; touch(p); p.update(debutStatus='confirmed', debutSeason=2026, debutDate=d); add_src(p, s, 'debut-open-mag')
for i in EXPECT:
    p = players[i]
    if p.get('debutStatus') != 'confirmed': touch(p); p['debutStatus'] = 'expected'; add_src(p, 'debut-open-mag')
players['finn-allen']['notes'] = 'In IPL squads since 2021 but, per Open Magazine, had never played an IPL match before 2026: squad membership is not a debut.'
players['zakary-foulkes']['unverifiedFields'] = ['nationality']; players['zakary-foulkes']['notes'] = 'Nationality unverified: Khel Now lists England; NZ assumed from his NZ international career.'
# ---------------- historical IPL (editorial; seasons NOT imported) ----------------
HIST = "andre-russell glenn-maxwell faf-du-plessis jake-fraser-mcgurk adam-zampa david-miller liam-livingstone mustafizur-rahman matheesha-pathirana devon-conway jonny-bairstow rahmanullah-gurbaz gus-atkinson deepak-hooda k-s-bharat gerald-coetzee spencer-johnson fazalhaq-farooqi maheesh-theekshana mujeeb-ur-rahman wiaan-mulder prithvi-shaw sarfaraz-khan rachin-ravindra jason-holder kyle-jamieson lungi-ngidi rahul-chahar ravi-bishnoi venkatesh-iyer anrich-nortje akeal-hosein matt-henry wanindu-hasaranga quinton-de-kock josh-inglis akash-deep rahul-tripathi shivam-mavi kuldeep-sen vignesh-puthur".split()
for p in players.values(): p.pop('historicalIpl', None)
for i in HIST:
    p = players[i]; touch(p); p['historicalIpl'] = dict(basis='editorial', note='Played in at least one IPL season before 2026 (maintainer knowledge). Seasons/franchises not imported; see README.')
# ---------------- statuses ----------------
cur = {i for t in teams.values() for i in t.get('squad', [])}
for p in players.values():
    st = []
    if p['id'] in cur: st.append('CURRENT_SQUAD')
    if any(a['outcome'] == 'sold' for a in p['auctions']): st.append('AUCTION_BOUGHT')
    if any(a['outcome'] == 'unsold' for a in p['auctions']): st.append('AUCTION_UNSOLD')
    if p.get('debutStatus') == 'confirmed': st.append('IPL_DEBUTANT')
    if p.get('historicalIpl'): st.append('HISTORICAL_IPL')
    if p.get('uncapped') is True: st.append('UNCAPPED')
    p['statuses'] = st
# teams: complete 25-man IPL 2026 squads
for t in teams.values():
    if t['category'] == 'ipl':
        t['squadStatus'] = 'verified-2026'; t['squadAsOf'] = TODAY
        t['squadNote'] = ('IPL 2026 squad as announced after the Dec 2025 auction (retained + auction buys) with all trades confirmed up to 15 Nov 2026 applied (%d players). '
                          'IPL 2027 retentions are due 17 Nov 2026, so this will change. Mid-season replacement signings appear under Recently active.' % len(t['squad']))
        assert len(t['squad']) == 25, (t['id'], len(t['squad']))
        assert len(set(t['squad'])) == len(t['squad'])
# duplicate checks
names = {}
for p in players.values():
    k = norm(p['name']); assert k not in names, ('dup name', p['name'], names[k]); names[k] = p['id']
mem = [i for t in teams.values() for i in t['squad']]; assert len(mem) == len(set(mem)), 'player in two squads'
assert all(i in players for t in teams.values() for i in t['squad'] + t['recentlyActive'])
A['events'] = [e for e in A['events'] if e['id'] != 'ipl-2026-auction'] + [dict(id='ipl-2026-auction', kind='auction', season=2026, date='2025-12-16', venue='Etihad Arena, Abu Dhabi',
   summary='77 players sold (29 overseas) for Rs 215.45 cr from a shortlist of 359-369; 79 went unsold (19 other players were sold in accelerated rounds after going unsold first). All 77 sales and all 79 unsold names are recorded on player.auctions.',
   source=SA_, soldCount=77, unsoldCount=79, totalSpendCr=215.45, mostExpensive=dict(player='cameron-green', team='kkr', priceCr=25.2))]
A['events'].sort(key=lambda e: e['date'])
P['players'] = sorted(players.values(), key=lambda p: p['name']); P['meta']['generated'] = TODAY
P['meta']['notes'] = ('verification: official | reported | reported-trade | editorial. statuses are derived tags (CURRENT_SQUAD is recomputed by the site from teams.json). debutStatus: confirmed = a source reports an IPL match in 2026; '
                      'expected = first-time IPL player per pre-season reports (match not confirmed); a player can be bought at auction without debuting. iplMatchSeasons null = not imported. unverifiedFields lists fields assumed rather than sourced.')
json.dump(P, open(root/'players.json', 'w', encoding='utf-8'), indent=1, ensure_ascii=False); json.dump(T, open(root/'teams.json', 'w', encoding='utf-8'), indent=1, ensure_ascii=False); json.dump(A, open(root/'auctions.json', 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
unv = [p for p in players.values() if p.get('unverifiedFields')]; edr = [p for p in players.values() if p.get('roleSource') == 'editorial']
print('total', len(players), '| new', len(new_ids), '| updated', len(upd_ids), '| unverifiedFields', len(unv), '| roles editorial', len(edr), '| no role', sum(1 for p in players.values() if not p.get('role')))
print('debut confirmed', sum(1 for p in players.values() if p.get('debutStatus') == 'confirmed'), 'expected', sum(1 for p in players.values() if p.get('debutStatus') == 'expected'), '| historical', sum(1 for p in players.values() if p.get('historicalIpl')), '| uncapped', sum(1 for p in players.values() if p.get('uncapped') is True))
print({t['short']: len(t['squad']) for t in teams.values() if t['category'] == 'ipl'})
