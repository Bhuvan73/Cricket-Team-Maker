/* drag-drop.js — pointer-event drag & drop (mouse + touch).
   Draggables: [data-drag]   (touch drags start from the .grip handle so the page can still scroll)
   Drop zones: [data-drop]
   Calls opts.onDrop(sourceDataset, targetDataset). */
window.CLB = window.CLB || {};
CLB.DragDrop = (function () {
  let st = null, lastDragEnd = 0, opts = {}, raf = 0;

  function start() {
    st.active = true;
    const g = document.createElement('div');
    g.className = 'drag-ghost';
    g.textContent = st.el.querySelector('.pname, .sname')?.textContent || 'Player';
    document.body.appendChild(g);
    st.ghost = g;
    st.el.classList.add('dragging');
    document.body.classList.add('is-dragging');
    document.body.dataset.dragKind = st.el.dataset.drag;
    (function loop() {            // keep scrolling while the pointer rests near a screen edge (touch users can't scroll mid-drag)
      if (!st || !st.active) return;
      const y = st.cy, h = window.innerHeight;
      if (y < 80) window.scrollBy(0, -Math.ceil((80 - y) / 5)); else if (y > h - 80) window.scrollBy(0, Math.ceil((y - (h - 80)) / 5));
      raf = requestAnimationFrame(loop);
    })();
  }
  function clearOver() { document.querySelectorAll('.drop-over').forEach(n => n.classList.remove('drop-over')); }
  function cleanup() {
    if (!st) return;
    st.el.classList.remove('dragging');
    cancelAnimationFrame(raf);
    st.ghost?.remove();
    clearOver();
    document.body.classList.remove('is-dragging');
    delete document.body.dataset.dragKind;
    st = null;
  }
  function targetAt(x, y) {
    const n = document.elementFromPoint(x, y);
    return n ? n.closest('[data-drop]') : null;
  }

  function init(o) {
    opts = o || {};
    document.addEventListener('pointerdown', e => {
      if (e.button > 0) return;
      const el = e.target.closest('[data-drag]');
      if (!el || el.dataset.disabled === 'true' || e.target.closest('button, input, select, textarea')) return;
      const touch = e.pointerType !== 'mouse';
      if (touch && !e.target.closest('.grip')) return;
      st = { el, id: e.pointerId, x: e.clientX, y: e.clientY, active: false };
    });
    document.addEventListener('pointermove', e => {
      if (!st || e.pointerId !== st.id) return;
      if (!st.active) { if (Math.hypot(e.clientX - st.x, e.clientY - st.y) < 6) return; start(); }
      e.preventDefault();
      st.cy = e.clientY;
      st.ghost.style.transform = `translate(${e.clientX + 12}px, ${e.clientY + 12}px)`;
      clearOver();
      const t = targetAt(e.clientX, e.clientY);
      if (t) t.classList.add('drop-over');
    }, { passive: false });
    document.addEventListener('pointerup', e => {
      if (!st || e.pointerId !== st.id) return;
      if (st.active) {
        const t = targetAt(e.clientX, e.clientY);
        const src = Object.assign({}, st.el.dataset);
        lastDragEnd = Date.now();
        cleanup();
        if (t && opts.onDrop) opts.onDrop(src, Object.assign({}, t.dataset));
      } else st = null;
    });
    document.addEventListener('pointercancel', () => { if (st?.active) lastDragEnd = Date.now(); cleanup(); });
    document.addEventListener('dragstart', e => { if (e.target.closest('[data-drag]')) e.preventDefault(); });
  }
  /* click handlers call this to ignore the click that browsers fire right after a drag */
  const justDragged = () => Date.now() - lastDragEnd < 40;
  return { init, justDragged };
})();
