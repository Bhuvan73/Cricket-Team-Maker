/* app.js — Lineup Builder page (frontend.html). */
(function () {
  const S = CLB.Storage, DB = CLB.DB;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ROLE = { BAT: 'Batter', BOWL: 'Bowler', AR: 'All-rounder', WK: 'Wicketkeeper' };
  const state = { team: null, mode: 'xi', viewMode: 'xi', tab: 'current', filter: 'all', query: '', role: 'all', armed: null, lineup: [] };
  const isIpl = () => state.team.category === 'ipl';
  const size = () => (isIpl() ? 12 : 11);
  const modeLabel = m => (m === 'bat' ? 'Batting first' : m === 'bowl' ? 'Bowling first' : 'Playing XI');

  /* ---------- boot ---------- */
  DB.load().then(boot).catch(() => {
    document.querySelector('main').innerHTML = '<p style="padding:40px;text-align:center;color:#91a2b8">Could not load player data. Keep the <b>data/</b> folder next to this page (see README).</p>';
  });

  function boot() {
    const sel = S.getTeam();
    const team = sel && DB.team(sel.teamId);
    if (!team) { location.replace('index.html'); return; }
    state.team = team;
    const prefs = S.getPrefs();
    state.mode = isIpl() ? (prefs.mode === 'bowl' ? 'bowl' : 'bat') : 'xi';
    state.viewMode = state.mode;
    state.tab = ['current', 'pool', 'recent'].includes(prefs.tab) ? prefs.tab : (team.squad.length ? 'current' : 'pool');
    state.filter = DB.filtersFor(team).includes(prefs.filter) ? prefs.filter : 'all';
    document.title = team.name + ' · Lineup Builder';
    loadLineup();
    CLB.DragDrop.init({ onDrop });
    wire();
    renderAll();
  }

  function loadLineup() {
    const raw = S.getLineup(state.team.id, state.mode, size());
    const seen = new Set();
    state.lineup = raw.map(id => (id && DB.player(id) && !seen.has(id) && seen.add(id)) ? id : null);
  }
  function save() { S.saveLineup(state.team.id, state.mode, state.lineup); }
  const placed = id => state.lineup.includes(id);
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('show'), 2200);
  }

  /* ---------- lineup operations ---------- */
  function placePlayer(id, idx) {
    if (placed(id)) { toast('Already in this lineup'); return false; }
    state.lineup[idx] = id;               // replaces whoever was there
    state.armed = null; save(); renderAll(); return true;
  }
  function moveSlot(from, to) {
    if (from === to || to < 0 || to >= size()) return;
    const t = state.lineup[to]; state.lineup[to] = state.lineup[from]; state.lineup[from] = t;   // empty target = move, occupied = swap
    state.armed = null; save(); renderAll();
  }
  function removeSlot(i) { state.lineup[i] = null; state.armed = null; save(); renderAll(); }
  function quickAdd(id) {
    if (placed(id)) return;
    const i = state.lineup.indexOf(null);
    if (i < 0) { toast('Lineup is full (' + size() + '). Remove or replace a player.'); return; }
    placePlayer(id, i);
  }
  function onDrop(src, tgt) {
    if (src.drag === 'pool' && tgt.drop === 'slot') placePlayer(src.id, +tgt.index);
    else if (src.drag === 'slot' && tgt.drop === 'slot') moveSlot(+src.index, +tgt.index);
    else if (src.drag === 'slot' && tgt.drop === 'pool') removeSlot(+src.index);
  }

  /* ---------- events ---------- */
  function wire() {
    $('batMode').onclick = () => setMode('bat');
    $('bowlMode').onclick = () => setMode('bowl');
    $('viewBat').onclick = () => { state.viewMode = 'bat'; renderTeamView(); };
    $('viewBowl').onclick = () => { state.viewMode = 'bowl'; renderTeamView(); };
    $('poolTabs').onclick = e => { const b = e.target.closest('[data-tab]'); if (b) setTab(b.dataset.tab); };
    $('filterChips').onclick = e => { const b = e.target.closest('[data-filter]'); if (b) { state.filter = b.dataset.filter; S.setPref('filter', state.filter); renderPool(); } };
    $('search').oninput = e => { state.query = e.target.value; renderPoolList(); };
    $('roleSel').onchange = e => { state.role = e.target.value; renderPoolList(); };
    $('poolList').onclick = e => {
      if (CLB.DragDrop.justDragged()) return;
      const go = e.target.closest('[data-goto]'); if (go) { setTab(go.dataset.goto); return; }
      const add = e.target.closest('[data-add]'); if (add) { quickAdd(add.dataset.add); return; }
      const row = e.target.closest('.prow'); if (!row || row.dataset.disabled === 'true') return;
      const same = state.armed && state.armed.kind === 'pool' && state.armed.id === row.dataset.id;
      state.armed = same ? null : { kind: 'pool', id: row.dataset.id };
      renderPoolList(); renderBoard(); renderArmed();
    };
    $('board').onclick = e => {
      if (CLB.DragDrop.justDragged()) return;
      const slot = e.target.closest('.slot'); if (!slot) return;
      const i = +slot.dataset.index;
      if (e.target.closest('[data-rm]')) return removeSlot(i);
      if (e.target.closest('[data-up]')) return moveSlot(i, i - 1);
      if (e.target.closest('[data-down]')) return moveSlot(i, i + 1);
      const a = state.armed;
      if (a && a.kind === 'pool') placePlayer(a.id, i);
      else if (a && a.kind === 'slot') { if (a.index === i) { state.armed = null; renderBoard(); renderArmed(); } else moveSlot(a.index, i); }
      else if (state.lineup[i]) { state.armed = { kind: 'slot', index: i, id: state.lineup[i] }; renderBoard(); renderArmed(); }
      else toast('Pick a player from the list first, or drag one here');
    };
    $('armedBar').onclick = e => {
      if (e.target.closest('[data-cancel]')) { state.armed = null; renderPoolList(); renderBoard(); renderArmed(); }
      if (e.target.closest('[data-jump]')) $('board').scrollIntoView({ behavior: 'smooth', block: 'center' });
    };
    $('clearBtn').onclick = () => {
      if (!confirm('Clear the ' + modeLabel(state.mode) + ' lineup?')) return;
      state.lineup = new Array(size()).fill(null); state.armed = null; save(); renderAll();
    };
    $('copyBtn').onclick = copyLineup;
    $('fsBtn').onclick = openFs; $('fsBtn2').onclick = openFs; $('fsClose').onclick = closeFs;
    $('fsBat').onclick = () => { state.viewMode = 'bat'; renderFs(); renderTeamView(); };
    $('fsBowl').onclick = () => { state.viewMode = 'bowl'; renderFs(); renderTeamView(); };
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('fsView').hidden) closeFs(); });
    document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement && !$('fsView').hidden) closeFs(); });
  }
  function setMode(m) {
    if (!isIpl() || m === state.mode) return;
    state.mode = state.viewMode = m; S.setPref('mode', m);
    state.armed = null; loadLineup(); renderAll();
  }
  function setTab(t) { state.tab = t; state.armed = null; S.setPref('tab', t); renderAll(); }

  /* ---------- theme ---------- */
  function applyTheme() {
    const t = state.team, r = document.documentElement.style, c = t.theme;
    r.setProperty('--team', c[0]); r.setProperty('--team2', c[1]); r.setProperty('--accent2', c[2]); r.setProperty('--glow', c[0] + '66');
    r.setProperty('--bg', `color-mix(in srgb, ${c[1]} 40%, #070d17)`);
    r.setProperty('--panel', `color-mix(in srgb, ${c[1]} 30%, #101d30)`);
    r.setProperty('--panel2', `color-mix(in srgb, ${c[1]} 34%, #14243a)`);
    const h = c[0].replace('#', ''), lum = (0.299 * parseInt(h.slice(0, 2), 16) + 0.587 * parseInt(h.slice(2, 4), 16) + 0.114 * parseInt(h.slice(4, 6), 16)) / 255;
    r.setProperty('--text-on-team', lum > 0.62 ? '#08111f' : '#ffffff');
  }

  /* ---------- render ---------- */
  function renderAll() { applyTheme(); renderHero(); renderPool(); renderBoard(); renderArmed(); renderTeamView(); }

  function renderHero() {
    const t = state.team;
    $('pageTitle').textContent = isIpl() ? 'IPL Team Lineup' : 'International Team Lineup';
    $('pageSub').textContent = isIpl()
      ? 'Build a Playing XII. Batting-first and bowling-first lineups are saved independently.'
      : 'Create a Playing XI. Drag players from the list into the numbered positions.';
    $('inningsField').hidden = !isIpl();
    $('batMode').classList.toggle('active', state.mode === 'bat');
    $('bowlMode').classList.toggle('active', state.mode === 'bowl');
    $('teamMark').innerHTML = `<img src="${t.logo}" alt="${esc(t.name)} logo">`;
    $('bannerName').textContent = t.name;
    $('bannerDesc').textContent = isIpl() ? modeLabel(state.mode) + ' · IPL franchise lineup' : 'ICC Full Member · Test-playing nation';
    $('formatTag').textContent = isIpl() ? 'PLAYING XII' : 'PLAYING XI';
    $('squadTitle').textContent = isIpl() ? 'Playing XII · ' + modeLabel(state.mode) : 'Playing XI';
  }

  function tabCounts() {
    const t = state.team;
    return { current: DB.currentSquad(t).length, pool: DB.data.players.length, recent: DB.recentlyActive(t).length };
  }
  function renderPool() {
    const t = state.team, c = tabCounts();
    $('poolTabs').innerHTML = [['current', 'Current squad'], ['pool', 'Potential & extended pool'], ['recent', 'Recently active']]
      .map(([k, l]) => `<button class="tab ${state.tab === k ? 'active' : ''}" data-tab="${k}">${l} <span class="cnt">${c[k]}</span></button>`).join('');
    const fc = $('filterChips');
    fc.hidden = state.tab !== 'pool';
    fc.innerHTML = DB.filtersFor(t).map(k => `<button class="chip ${state.filter === k ? 'active' : ''}" data-filter="${k}">${DB.FILTERS[k].label} <span class="cnt">${DB.extended(t, k).length}</span></button>`).join('');
    renderPoolList();
  }

  function poolSource() {
    const t = state.team;
    if (state.tab === 'current') return DB.currentSquad(t);
    if (state.tab === 'recent') return DB.recentlyActive(t);
    return DB.extended(t, state.filter);
  }
  function chips(p) {
    const out = [];
    const ct = DB.currentTeamId(p.id), t = ct && DB.team(ct);
    if (t) out.push(`<span class="tag team ${ct === state.team.id ? 'own' : ''}" style="--c:${t.accent}">${esc(t.short)}</span>`);
    else out.push('<span class="tag muted">No IPL squad</span>');
    DB.formerTeams(p).forEach(id => { const f = DB.team(id); if (f) out.push(`<span class="tag ghost" title="Former team">ex-${esc(f.short)}</span>`); });
    const au = (p.auctions || []).find(x => x.season === 2026) || (p.auctions || [])[0];
    if (au) out.push(au.outcome === 'unsold'
      ? '<span class="tag unsold" title="Went unsold at the 2026 auction (auction participation, not an IPL appearance)">Unsold \'26</span>'
      : `<span class="tag auc" title="Bought at auction (separate from match appearances)">Bought${au.priceCr ? ' ' + (au.priceCr < 1 ? '₹' + Math.round(au.priceCr * 100) + ' lakh' : '₹' + au.priceCr + ' cr') : ''}</span>`);
    if (p.debutStatus === 'confirmed') out.push('<span class="tag debut" title="IPL debut in 2026 confirmed by a source">Debut ✓ 2026</span>');
    else if (p.debutStatus === 'expected') out.push('<span class="tag debut exp" title="First-time IPL player per pre-season reports; match not confirmed">Debut expected</span>');
    if (p.uncapped) out.push('<span class="tag unc">Uncapped</span>');
    return out.join('');
  }
  function renderPoolList() {
    const list = $('poolList'), keep = list.scrollTop;
    const all = poolSource(), rows = DB.search(all, state.query, state.role);
    const t = state.team;
    let html = '';
    if (state.tab === 'current' && t.squadNote) html += `<div class="note">${esc(t.squadNote)}</div>`;
    if (state.tab === 'pool' && DB.FILTERS[state.filter].note) html += `<div class="note">${esc(DB.FILTERS[state.filter].note)}</div>`;
    if (!all.length) {
      html += state.tab === 'pool'
        ? '<div class="empty">No players in this filter yet. The dataset only holds verified records — see README to add more.</div>'
        : state.tab === 'recent'
          ? '<div class="empty">No recently-active players have been verified for this team yet.</div>'
          : `<div class="empty">No verified current squad loaded for ${esc(t.name)}.<br><button class="btn" data-goto="pool" style="margin-top:12px">Browse Extended Pool</button></div>`;
    } else if (!rows.length) html += '<div class="empty">No players match your search.</div>';
    html += rows.map(p => {
      const inL = placed(p.id), armed = state.armed && state.armed.kind === 'pool' && state.armed.id === p.id;
      const bits = [p.role ? ROLE[p.role] : 'Role n/a', p.nationality].filter(Boolean).join(' · ');
      return `<div class="prow ${inL ? 'in' : ''} ${armed ? 'armed' : ''}" data-drag="pool" data-id="${p.id}" data-disabled="${inL}" title="${esc(p.notes || '')}">
        <span class="grip" aria-hidden="true">⋮⋮</span>
        <div class="pinfo"><div class="pname">${esc(p.name)}</div><div class="pmeta">${esc(bits)}</div></div>
        <div class="ptags">${chips(p)}</div>
        ${inL ? '<span class="tag in-xi">In lineup</span>' : `<button class="add" data-add="${p.id}" aria-label="Add ${esc(p.name)} to next free position" title="Add to next free position">+</button>`}
      </div>`;
    }).join('');
    $('poolCount').textContent = `Showing ${rows.length} of ${all.length}`;
    list.innerHTML = html; list.scrollTop = keep;
  }

  function renderBoard() {
    const n = size(), a = state.armed;
    $('board').innerHTML = state.lineup.map((id, i) => {
      const p = id && DB.player(id), ct = p && DB.team(DB.currentTeamId(p.id));
      const armedSlot = a && a.kind === 'slot' && a.index === i;
      const body = p
        ? `<div class="sbody" data-drag="slot" data-index="${i}" data-id="${p.id}"><span class="grip" aria-hidden="true">⋮⋮</span>
             <div class="pinfo"><div class="sname">${esc(p.name)}</div><div class="pmeta">${esc([p.role ? ROLE[p.role] : null, ct ? ct.short : p.nationality].filter(Boolean).join(' · '))}</div></div></div>`
        : '<div class="sempty">Empty — drag a player here</div>';
      return `<div class="slot ${p ? 'filled' : ''} ${armedSlot ? 'armed' : ''} ${a && !armedSlot ? 'target' : ''}" data-drop="slot" data-index="${i}">
        <span class="num">${i + 1}</span>${body}
        <div class="sbtns"><button data-up aria-label="Move up" ${i === 0 || !p ? 'disabled' : ''}>↑</button><button data-down aria-label="Move down" ${i === n - 1 || !p ? 'disabled' : ''}>↓</button><button data-rm aria-label="Remove" ${p ? '' : 'disabled'}>✕</button></div>
      </div>`;
    }).join('');
    const filled = state.lineup.filter(Boolean).length;
    $('countLabel').textContent = `${filled} / ${n} SELECTED`;
  }

  function renderArmed() {
    const bar = $('armedBar'), a = state.armed, p = a && DB.player(a.id);
    bar.hidden = !p;
    if (p) bar.innerHTML = `<span><b>${esc(p.name)}</b> ${a.kind === 'pool' ? 'selected — tap a numbered position' : 'picked up — tap another position to swap'}</span>
      <span><button class="btn" data-jump>Go to lineup ↓</button> <button class="btn" data-cancel>Cancel</button></span>`;
  }

  function viewLineup() {
    return state.viewMode === state.mode ? state.lineup : S.getLineup(state.team.id, state.viewMode, size());
  }
  function renderTeamView() {
    const t = state.team, ids = viewLineup(), n = size();
    $('viewSwitch').hidden = !isIpl();
    $('viewBat').classList.toggle('active', state.viewMode === 'bat');
    $('viewBowl').classList.toggle('active', state.viewMode === 'bowl');
    $('tvTitle').textContent = 'Team view · ' + (isIpl() ? modeLabel(state.viewMode) : 'Batting order');
    $('tvMark').innerHTML = `<img src="${t.logo}" alt="">`;
    $('tvTeam').textContent = t.name;
    $('tvFormat').textContent = (isIpl() ? 'IPL · Playing XII · ' + modeLabel(state.viewMode) : 'International · Playing XI');
    $('teamView').innerHTML = ids.map((id, i) => {
      const p = id && DB.player(id), ct = p && DB.team(DB.currentTeamId(p.id));
      return `<div class="tv-row"><span class="tv-num">${i + 1}</span>
        <span class="tv-name ${p ? '' : 'empty'}">${p ? esc(p.name) : '—'}</span>
        <span class="tv-role">${p && p.role ? ROLE[p.role] : ''}</span>
        <span class="tv-team">${p ? esc(ct ? ct.short : p.nationality) : ''}</span></div>`;
    }).join('');
    const ps = ids.map(i => i && DB.player(i)).filter(Boolean), filled = ps.length;
    $('filledStat').textContent = filled; $('remainingStat').textContent = n - filled; $('formatStat').textContent = n === 12 ? 'XII' : 'XI';
    const cnt = r => ps.filter(p => p.role === r).length;
    $('roleMix').textContent = filled ? `${cnt('WK')} WK · ${cnt('BAT')} BAT · ${cnt('AR')} AR · ${cnt('BOWL')} BOWL · ${ps.filter(p => !p.role).length} role n/a` : 'No players selected yet';
  }

  /* ---------- full-screen squad view: only the selected players ---------- */
  function renderFs() {
    const t = state.team, ids = viewLineup();
    $('fsMark').innerHTML = `<img src="${t.logo}" alt="">`;
    $('fsTeam').textContent = t.name;
    $('fsFmt').textContent = isIpl() ? 'Playing XII · ' + modeLabel(state.viewMode) : 'Playing XI';
    $('fsSwitch').hidden = !isIpl();
    $('fsBat').classList.toggle('active', state.viewMode === 'bat');
    $('fsBowl').classList.toggle('active', state.viewMode === 'bowl');
    $('fsList').innerHTML = ids.map((id, i) => {
      const p = id && DB.player(id);
      return `<li class="${p ? '' : 'empty'}"><span class="fs-n">${i + 1}</span><span class="fs-name">${p ? esc(p.name) : '—'}</span></li>`;
    }).join('');
  }
  function openFs() {
    state.viewMode = state.mode; renderFs();
    $('fsView').hidden = false; document.body.classList.add('fs-open');
    try { const r = $('fsView').requestFullscreen && $('fsView').requestFullscreen(); if (r && r.catch) r.catch(() => {}); } catch (e) {}
    $('fsClose').focus();
  }
  function closeFs() {
    $('fsView').hidden = true; document.body.classList.remove('fs-open');
    if (document.fullscreenElement) { try { document.exitFullscreen(); } catch (e) {} }
    renderTeamView();
  }

  function copyLineup() {
    const t = state.team, ids = viewLineup();
    const text = `${t.name} — ${isIpl() ? 'Playing XII · ' + modeLabel(state.viewMode) : 'Playing XI'}\n` +
      ids.map((id, i) => { const p = id && DB.player(id); return `${i + 1}. ${p ? p.name + (p.role ? ' (' + ROLE[p.role] + ')' : '') : '—'}`; }).join('\n');
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(() => toast('Lineup copied'), () => prompt('Copy your lineup:', text));
    else prompt('Copy your lineup:', text);
  }
})();
