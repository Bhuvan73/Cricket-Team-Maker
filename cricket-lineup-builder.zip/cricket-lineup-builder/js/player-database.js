/* player-database.js — loads data/*.json (falls back to data/data.js when fetch() is blocked, e.g. file://)
   and answers the three player-category queries. A player is stored once; team lists only reference IDs. */
window.CLB = window.CLB || {};
CLB.DB = (function () {
  let D = null, byId = {}, teamById = {}, currentTeamOf = {};
  const files = ['teams', 'players', 'auctions'];

  async function fetchAll() {
    const out = {};
    for (const f of files) {
      const r = await fetch('data/' + f + '.json', { cache: 'no-cache' });
      if (!r.ok) throw new Error(f + ' ' + r.status);
      out[f] = await r.json();
    }
    return out;
  }

  function index(raw) {
    D = { teams: raw.teams.teams, players: raw.players.players, sources: raw.players.sources || {}, auctions: raw.auctions, meta: raw.players.meta || {} };
    byId = {}; teamById = {}; currentTeamOf = {};
    D.players.forEach(p => { byId[p.id] = p; });
    D.teams.forEach(t => {
      teamById[t.id] = t;
      (t.squad || []).forEach(id => { currentTeamOf[id] = t.id; });
    });
    return D;
  }

  async function load() {
    if (D) return D;
    let raw = null, via = 'json';
    try {
      if (location.protocol === 'file:' && window.CLB_DATA_FALLBACK) throw new Error('file protocol'); // fetch() is blocked on file://
      raw = await fetchAll();
    } catch (e) {
      if (window.CLB_DATA_FALLBACK) { raw = window.CLB_DATA_FALLBACK; via = 'fallback'; } else throw e;
    }
    index(raw); CLB.DB.via = via; return D;
  }

  const team = id => teamById[id] || null;
  const player = id => byId[id] || null;
  const teams = cat => D.teams.filter(t => !cat || t.category === cat);
  const currentTeamId = id => currentTeamOf[id] || null;
  const names = ids => (ids || []).map(player).filter(Boolean);
  const formerTeams = p => [...new Set((p.teamHistory || []).map(h => h.team))].filter(t => t !== currentTeamOf[p.id]);

  /* CATEGORY 1 — current squad (official team list) */
  const currentSquad = t => names(t.squad);

  /* CATEGORY 3 — recently active: explicit list + anyone whose teamHistory names this team but who is not in its squad now */
  function recentlyActive(t) {
    const ids = new Set(t.recentlyActive || []);
    D.players.forEach(p => {
      if ((p.teamHistory || []).some(h => h.team === t.id) && currentTeamOf[p.id] !== t.id) ids.add(p.id);
    });
    return names([...ids]);
  }

  /* CATEGORY 2 — independent extended pool. Includes everyone, regardless of selected team. */
  const has = (p, tag) => tag === 'CURRENT_SQUAD' ? !!currentTeamOf[p.id] : (p.statuses || []).includes(tag);
  const FILTERS = {
    all:       { label: 'All Players',               fn: () => true },
    other:     { label: 'Other IPL Franchises',      fn: (p, t) => !!currentTeamOf[p.id] && currentTeamOf[p.id] !== t.id, iplOnly: true },
    auction26: { label: '2026 Auction Purchases',    fn: p => has(p, 'AUCTION_BOUGHT'), note: 'Players bought at the Dec 2025 auction (incl. accelerated rounds). Bought is not the same as debuted.' },
    unsold:    { label: 'Unsold Auction Players',    fn: p => has(p, 'AUCTION_UNSOLD'), note: 'Went under the hammer at the 2026 auction and were not bought. Auction participation is not an IPL appearance.' },
    debut:     { label: '2026 IPL Debutants',        fn: p => p.debutStatus === 'confirmed' || p.debutStatus === 'expected', note: 'Debut ✓ = a source reports an IPL match in 2026. Debut expected = first-time IPL player per pre-season reports; match not confirmed.' },
    uncapped:  { label: 'Uncapped Players',          fn: p => p.uncapped === true, note: 'Uncapped at the time of the 2026 auction (per auction lists).' },
    historical:{ label: 'Historical IPL Players',    fn: p => has(p, 'HISTORICAL_IPL'), note: 'Played in an IPL season before 2026. Maintainer-verified only for the players listed; per-season data is not imported yet.' },
    auction:   { label: 'Previous Auction Players',  fn: p => (p.auctions || []).length > 0 },
    ipl:       { label: 'IPL Players (2016–2026)',   fn: p => (p.iplSquadSeasons || []).length > 0 || (p.iplMatchSeasons || []).length > 0, note: 'Means IPL squad membership; match appearances are not imported yet.' },
    nation:    { label: 'Same nationality',          fn: (p, t) => p.nationality === t.name, intlOnly: true }
  };
  function filtersFor(t) {
    return Object.keys(FILTERS).filter(k => t.category === 'ipl' ? !FILTERS[k].intlOnly : !FILTERS[k].iplOnly);
  }
  const extended = (t, f) => D.players.filter(p => (FILTERS[f] || FILTERS.all).fn(p, t));

  function search(list, q, role) {
    q = (q || '').trim().toLowerCase();
    return list.filter(p => (role === 'all' || !role || p.role === role) &&
      (!q || p.name.toLowerCase().includes(q) || (p.aliases || []).some(a => a.toLowerCase().includes(q)) || (p.nationality || '').toLowerCase().includes(q)))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  return { load, has, team, player, teams, currentTeamId, formerTeams, currentSquad, recentlyActive, extended, search, FILTERS, filtersFor, get data() { return D; } };
})();
