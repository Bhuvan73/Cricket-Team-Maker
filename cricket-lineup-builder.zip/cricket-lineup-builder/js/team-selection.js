/* team-selection.js — Page 1 logic (original behaviour preserved; data now comes from data/teams.json). */
(function () {
  let internationalTeams = [], iplTeams = [];
  let activeTab = 'international', selectedTeamId = null;
  const teamGrid = document.getElementById('teamGrid');
  const continueBtn = document.getElementById('continueBtn');

  function renderGrid() {
    const teams = activeTab === 'international' ? internationalTeams : iplTeams;
    teamGrid.innerHTML = '';
    teams.forEach(team => {
      const tile = document.createElement('div');
      tile.className = 'team-tile' + (team.id === selectedTeamId ? ' selected' : '');
      tile.style.setProperty('--team-accent', team.accent);
      tile.style.setProperty('--team-accent-glow', team.accent + '55');
      tile.innerHTML = `
      <div class="team-logo">
        <img src="${team.logo}" alt="${team.name} Logo" onerror="this.style.display='none'; this.parentElement.textContent='${team.short}';">
      </div>
      <div class="team-name">${team.name}</div>`;
      tile.addEventListener('click', () => { selectedTeamId = team.id; renderGrid(); continueBtn.disabled = false; });
      teamGrid.appendChild(tile);
    });
  }

  document.getElementById('tabSwitcher').addEventListener('click', e => {
    const btn = e.target.closest('.tab-btn');
    if (!btn || btn.dataset.tab === activeTab) return;
    activeTab = btn.dataset.tab; selectedTeamId = null; continueBtn.disabled = true;
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === activeTab));
    renderGrid();
  });

  continueBtn.addEventListener('click', () => {
    if (!selectedTeamId) return;
    const teams = activeTab === 'international' ? internationalTeams : iplTeams;
    const team = teams.find(t => t.id === selectedTeamId);
    CLB.Storage.setTeam({ category: activeTab, teamId: team.id, teamName: team.name, teamShort: team.short, teamAccent: team.accent });
    window.location.href = 'frontend.html';
  });

  CLB.DB.load().then(db => {
    internationalTeams = db.teams.filter(t => t.category === 'international');
    iplTeams = db.teams.filter(t => t.category === 'ipl');
    // Returning from the lineup page: restore the previous selection (lineups are NOT erased).
    const saved = CLB.Storage.getTeam();
    if (saved && db.teams.some(t => t.id === saved.teamId)) {
      activeTab = saved.category === 'ipl' ? 'ipl' : 'international';
      selectedTeamId = saved.teamId;
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === activeTab));
      continueBtn.disabled = false;
    }
    renderGrid();
  }).catch(() => {
    teamGrid.innerHTML = '<p style="color:#91a2b8;text-align:center;grid-column:1/-1">Could not load team data. Keep the data/ folder next to this page (see README).</p>';
  });
})();
