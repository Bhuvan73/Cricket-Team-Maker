/* storage.js — all localStorage access lives here. */
window.CLB = window.CLB || {};
CLB.Storage = (function () {
  const K = { team: 'cricket_selected_team', lineups: 'cricket_lineups_v2', prefs: 'cricket_prefs_v1' };
  function read(key, def) {
    try { const v = JSON.parse(localStorage.getItem(key)); return v == null ? def : v; } catch (e) { return def; }
  }
  function write(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); return true; } catch (e) { return false; }
  }
  return {
    getTeam() { return read(K.team, null); },
    setTeam(sel) { return write(K.team, sel); },
    /* Lineups are stored per team AND per mode: "ind:xi", "srh:bat", "srh:bowl". Values are player IDs (null = empty slot). */
    getLineup(teamId, mode, size) {
      const stored = read(K.lineups, {})[teamId + ':' + mode] || [];
      const out = [];
      for (let i = 0; i < size; i++) out.push(stored[i] || null);
      return out;
    },
    saveLineup(teamId, mode, ids) {
      const all = read(K.lineups, {});
      all[teamId + ':' + mode] = ids;
      return write(K.lineups, all);
    },
    getPrefs() { return read(K.prefs, {}); },
    setPref(key, val) { const p = read(K.prefs, {}); p[key] = val; write(K.prefs, p); }
  };
})();
